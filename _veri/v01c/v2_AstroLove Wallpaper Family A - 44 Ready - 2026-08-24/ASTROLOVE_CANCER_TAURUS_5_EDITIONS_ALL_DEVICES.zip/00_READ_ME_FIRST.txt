ASTROLOVE — CANCER + TAURUS
MATCHING COUPLE ZODIAC WALLPAPERS

ONE COMPLETE INSTANT-DOWNLOAD PACKAGE
5 color editions x 4 device categories = 20 wallpapers

FOLDERS
01_PHONE_1440x3200
02_TABLET_2200x3200
03_DESKTOP_LAPTOP_6144x3840
04_WATCH_1200x1200

EDITIONS IN EVERY FOLDER
01 Champagne Ivory
02 Deep Black
03 Midnight Blue
04 Warm Parchment
05 Pure White

DOWNLOAD FROM ETSY
Open Etsy.com in a browser, then go to Your Account > Purchases and reviews >
Download Files. Guest buyers can use the download link in the receipt email.

UNZIP AND USE
Computer: double-click the ZIP or choose Extract All.
iPhone/iPad: open the ZIP in the Files app.
Android: open the ZIP in Files or the device file manager and choose Extract.
Choose the matching device folder and set the preferred edition as wallpaper.
Keep the original aspect ratio; some device screens or UI overlays may crop a
small amount. A compact installation guide PDF is included in this ZIP.

IMAGE QUALITY
- Phone: 1440 x 3200 px
- Tablet: 2200 x 3200 px
- Desktop/Laptop: 6144 x 3840 px
- Watch: 1200 x 1200 px
- Baseline JPEG, 4:4:4 chroma, embedded sRGB profile
- Quality 92; Warm Parchment Watch quality 95

LICENSE
Personal use only. Copyright remains with AstroLove. Resale, redistribution,
sharing, sublicensing, or uploading to print-on-demand platforms is prohibited.

Thank you for choosing AstroLove — The Shape of Your Connection.
